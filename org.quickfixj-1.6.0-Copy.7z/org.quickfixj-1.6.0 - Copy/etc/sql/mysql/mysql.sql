source quickfix_database.sql;
source sessions_table.sql;
source messages_table.sql;
source messages_log_table.sql;
source event_log_table.sql;